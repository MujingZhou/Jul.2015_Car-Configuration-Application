package driver;

import model.Automotive;
import util.Util;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 05 2015
 * 
 *  class -- This class is used to initialize the Automotive and serialize and deserialize it.
 */

public class Driver {
    
    public static void main(String[] args) {
        Automotive FordZTW=new Automotive();
        Util util1=new Util();
        FordZTW=util1.buildAutoObject("Ford Focus.txt",FordZTW);
        
        FordZTW.printAuto();
        
        util1.serializeAuto(FordZTW,"A.dat");
        Automotive newFordZTW=util1.deserializeAuto("A.dat");
        
        
        newFordZTW.setBasePrice(10000);
        newFordZTW.setName("Focus Wagon");
        
        
        
        /************************************Test find************************************/       
        if (newFordZTW.findOptionSet("Transmission")>=0)
        {
            System.out.println("Given option set found");
        }
        
        if (newFordZTW.findOptionInAuto("Color", "Fort Knox Gold Clearcoat Metallic")>=0)
        {
            System.out.println("Given option found");
        }        
        /************************************Test find************************************/
        
        
        /************************************Test update************************************/       
        newFordZTW.updateOptionSet("Power Moonroof", "Moonroof Power new");       
        newFordZTW.updateOption("Color", "Infra-Red Clearcoat", "Red");
        newFordZTW.updateOption("Color", "Liquid Grey Clearcoat Metallic", 100);
        newFordZTW.updateOption("Color", "Grabber Green Clearcoat Metallic", "Green new", 200);
        newFordZTW.updateOptionSet(0, "Color1");
        newFordZTW.updateOption("Transmission", 0,"Totally-Automatic");
        newFordZTW.updateOption("Transmission", 0, 100);   
        newFordZTW.updateOption("Transmission", 1, "Manual 2",-1000); 
        newFordZTW.updateOption(0, 6, "Twilight Blue Clearcoat Metallic2"); 
        newFordZTW.updateOption(0, 6, -100);
        newFordZTW.updateOption(0, 6, "Twilight Blue Clearcoat Metallic3",-175); 
        newFordZTW.updateOption(0, "Sangria Red Clearcoat Metallic", "Sangria Red Clearcoat Metallic2"); 
        newFordZTW.updateOption(0, "Sangria Red Clearcoat Metallic", 125); 
        newFordZTW.updateOption(0, "French Blue Clearcoat Metallic", "French Blue Clearcoat Metallic2",250); 
        /************************************Test update************************************/
        
        
        /************************************Test delete************************************/        
        newFordZTW.deleteOptionSet("Brakes/Traction Control");
        newFordZTW.deleteOptionSet(3);
        newFordZTW.deleteOption("Color1", "Cloud 9 White Clearcoat");
        newFordZTW.deleteOption(0, "Pitch Black Clearcoat");
        newFordZTW.deleteOption(0, 0);                
        /************************************Test delete************************************/
        newFordZTW.printAuto();
     
       
        
        
    }

}
