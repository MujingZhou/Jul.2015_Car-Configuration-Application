package model;

import java.io.Serializable;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 05 2015
 * 
 * Automotive class -- This class is the main class for creating an Auto object.
 * An Auto object has the model name, base price and an array of type OptionSet which
 * stores available options(like color, Transmission and so on). A couple of methods are
 * created for basic operations of the Auto object.
 * This class implements the Serializable Interface for serialization in the Driver class.
 */

public class Automotive implements Serializable {

    private static final long serialVersionUID = 1L;
    private String name;
    private float basePrice;
    private OptionSet optSet[];

    /*
     * Automotive -- default constructor of Automotive class with no argument.
     */
    public Automotive() {
    }

    /*
     * Automotive -- constructor of Automotive class with three arguments which
     * initialize the name and basePrice fields as well as initialize the optSet
     * field with the optionSetSize.
     */
    public Automotive(String name, float basePrice, int optionSetSize) {
        setName(name);
        setBasePrice(basePrice);
        optSet = new OptionSet[optionSetSize];
        for (int i = 0; i < optionSetSize; i++) {
            optSet[i] = new OptionSet();
        }
    }

    /*
     * setName -- set the name field of the Automotive class.
     */
    public void setName(String name) {
        this.name = name;
    }

    /*
     * setBasePrice -- set the name field of the Automotive class.
     */
    public void setBasePrice(float basePrice) {
        this.basePrice = basePrice;
    }

    /*
     * setOptionSet -- set the optSet field of the Automotive class by given
     * array of options names.
     */
    public void setOptionSet(String[] options) {
        for (int i = 0; i < options.length; i++) {
            optSet[i].setName(options[i]);
        }
    }

    /*
     * setOption -- set values of Option(in context of OptionSet). optionSetName
     * is used to determine which OptionSet will be used to set the following
     * option values. Arrays of option names and prices will be used to set the
     * option values.
     */
    public void setOption(String optionSetName, String[] optName,
            float[] optPrice) {

        int index = findOptionSet(optionSetName);
        if (index >= 0) {
            optSet[index] = new OptionSet(optionSetName, optName.length);
            for (int i = 0; i < optName.length; i++) {
                optSet[index].getOpt(i).setName(optName[i]);
                optSet[index].getOpt(i).setPrice(optPrice[i]);
            }
        }

    }

    /*
     * getName -- get the value of the name field of the Automotive class.
     */
    public String getName() {
        return name;
    }

    /*
     * getBasePrice -- get the value of basePrice field of the Automotive class.
     */
    public float getBasePrice() {
        return basePrice;
    }

    /*
     * getOptionSet -- get the OptionSet object via the index of the optSet
     * array.
     */
    public OptionSet getOptionSet(int OptionSetIndex) {
        return optSet[OptionSetIndex];
    }

    /*
     * findOptionSet -- given a name of an OptionSet, determined whether such
     * optionSet can be found in optSet array. If found, the index of the optSet
     * array which matches the given string name will be returned. If not found,
     * -1 will be returned.
     */
    public int findOptionSet(String optSetName) {
        for (int i = 0; i < optSet.length; i++) {
            if (optSet[i].getName().equals(optSetName)) {
                return i;
            }
        }
        return -1;
    }

    /*
     * findOptionInAuto -- given the name of an OptionSet and the name of an
     * option, determined whether such option can be found in the given
     * OptionSet. If found, the index of the option array which matches the
     * given string name will be returned. If not found, -1 will be returned.
     */
    public int findOptionInAuto(String optSetName, String optName) {
        int optSetIndex = findOptionSet(optSetName);
        if (optSetIndex >= 0) {
            return optSet[optSetIndex].findOptionInSet(optName);
        } else
            return -1;
    }

    /*
     * updateOptionSet -- given the old name of the OptionSet, if such OptionSet
     * can be found, set the name of this OptionSet to be the new name given by
     * newName parameter. If not found, just ignore it.
     */
    public void updateOptionSet(String oldName, String newName) {
        int index = findOptionSet(oldName);
        if (index >= 0) {
            optSet[index].setName(newName);
        }
    }

    /*************************/
    public void updateOptionSet(int index, String newName) {
        if (index >= 0 && index <= optSet.length - 1) {
            optSet[index].setName(newName);
        } else {
            System.out
                    .println("Option Set index out of bound, can not update option set name");
        }
    }

    public void updateOption(String optSetName, int optIndex, String optNewName) {
        int optSetIndex = findOptionSet(optSetName);
        if (optSetIndex >= 0) {
            OptionSet ops1 = optSet[optSetIndex];
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setName(optNewName);
            } else {
                System.out
                        .println("Option index out of bound, can not update option name");
            }
        } else {
            System.out
                    .println("option set name does not exist, can not update");
        }
    }

    public void updateOption(int optSetIndex, int optIndex, String optNewName) {
        if (optSetIndex >= 0 && optSetIndex < optSet.length - 1) {
            OptionSet ops1 = optSet[optSetIndex];
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setName(optNewName);
            } else {
                System.out
                        .println("Option index out of bound, can not update option name");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not update option name");
        }
    }

    public void updateOption(String optSetName, int optIndex, float newPrice) {
        int optSetIndex = findOptionSet(optSetName);
        if (optSetIndex >= 0) {
            OptionSet ops1 = optSet[optSetIndex];
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setPrice(newPrice);
            } else {
                System.out
                        .println("Option index out of bound, can not update price");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not update option price");
        }
    }

    public void updateOption(String optSetName, int optIndex,
            String optNewName, float newPrice) {
        int optSetIndex = findOptionSet(optSetName);
        if (optSetIndex >= 0) {
            OptionSet ops1 = optSet[optSetIndex];
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setName(optNewName);
                optSet[optSetIndex].getOpt(optIndex).setPrice(newPrice);
            } else {
                System.out
                        .println("Option index out of bound, can not update price");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not update option name and price");
        }
    }

    public void updateOption(int optSetIndex, int optIndex, float newPrice) {
        if (optSetIndex >= 0 && optSetIndex < optSet.length - 1) {
            OptionSet ops1 = optSet[optSetIndex];
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setPrice(newPrice);
            } else {
                System.out
                        .println("Option index out of bound, can not update price");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not update price");
        }
    }

    public void updateOption(int optSetIndex, int optIndex, String optNewName,
            float newPrice) {
        if (optSetIndex >= 0 && optSetIndex < optSet.length - 1) {
            OptionSet ops1 = optSet[optSetIndex];
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setName(optNewName);
                optSet[optSetIndex].getOpt(optIndex).setPrice(newPrice);
            } else {
                System.out
                        .println("Option index out of bound, can not update price");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not update price");
        }
    }

    public void updateOption(int optSetIndex, String optOldName,
            String optNewName) {
        if (optSetIndex >= 0 && optSetIndex < optSet.length - 1) {
            OptionSet ops1 = optSet[optSetIndex];
            int optIndex = findOptionInAuto(optSet[optSetIndex].getName(),
                    optOldName);
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setName(optNewName);
            } else {
                System.out
                        .println("Option index out of bound, can not update price");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not update price");
        }
    }

    public void updateOption(int optSetIndex, String optOldName,
            float optNewPrice) {
        if (optSetIndex >= 0 && optSetIndex < optSet.length - 1) {
            OptionSet ops1 = optSet[optSetIndex];
            int optIndex = findOptionInAuto(optSet[optSetIndex].getName(),
                    optOldName);
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setPrice(optNewPrice);
            } else {
                System.out
                        .println("Option index out of bound, can not update price");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not update price");
        }
    }

    public void updateOption(int optSetIndex, String optOldName,
            String optNewName, float optNewPrice) {
        if (optSetIndex >= 0 && optSetIndex < optSet.length - 1) {
            OptionSet ops1 = optSet[optSetIndex];
            int optIndex = findOptionInAuto(optSet[optSetIndex].getName(),
                    optOldName);
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].getOpt(optIndex).setName(optNewName);
                optSet[optSetIndex].getOpt(optIndex).setPrice(optNewPrice);
            } else {
                System.out
                        .println("Option index out of bound, can not update price");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not update price");
        }
    }

    /*
     * updateOption -- given the name of the OptionSet and the old name of the
     * option, if such Option in such OptionSet can be found, set the name of
     * this Option to be the new name given by optnewName parameter. If not
     * found, just ignore it.
     */
    public void updateOption(String optSetName, String optOldName,
            String optNewName) {
        int optIndex = findOptionInAuto(optSetName, optOldName);
        if (optIndex >= 0) {
            int optSetIndex = findOptionSet(optSetName);
            if (optSetIndex >= 0)
                optSet[optSetIndex].getOpt(optIndex).setName(optNewName);
        }
    }

    /*
     * updateOption -- given the name of the OptionSet and the old name of the
     * option, if such Option in such OptionSet can be found, set the price of
     * this Option to be the new price given by newPrice parameter. If not
     * found, just ignore it.
     */
    public void updateOption(String optSetName, String optOldName,
            float newPrice) {
        int optIndex = findOptionInAuto(optSetName, optOldName);
        if (optIndex >= 0) {
            optSet[findOptionSet(optSetName)].getOpt(optIndex).setPrice(
                    newPrice);
        }
    }

    /*
     * updateOption -- given the name of the OptionSet and the old name of the
     * option, if such Option in such OptionSet can be found, set both the name
     * and price of this Option to be the new name and new price given by
     * optNewName and newPrice parameters. If not found, just ignore it.
     */
    public void updateOption(String optSetName, String optOldName,
            String optNewName, float newPrice) {
        int optIndex = findOptionInAuto(optSetName, optOldName);
        if (optIndex >= 0) {
            optSet[findOptionSet(optSetName)].getOpt(optIndex).setName(
                    optNewName);
            optSet[findOptionSet(optSetName)].getOpt(optIndex).setPrice(
                    newPrice);
        }
    }

    /*
     * deleteOptionSet -- given the name of an OptionSet, if it can be found in
     * optSet, delete it.
     */
    public void deleteOptionSet(String optSetName) {
        int index = findOptionSet(optSetName);
        if (index >= 0) {
            optSet[index] = null;
        }
    }

    public void deleteOptionSet(int optSetIndex) {
        if (optSetIndex >= 0 && optSetIndex <= optSet.length - 1) {
            optSet[optSetIndex] = null;
        } else {
            System.out
                    .println("Option Set index out of bound, can not delete option set");
        }
    }

    public void deleteOption(int optSetIndex, String optName) {
        if (optSetIndex >= 0 && optSetIndex <= optSet.length - 1) {
            OptionSet ops1 = optSet[optSetIndex];
            int optIndex = findOptionInAuto(ops1.getName(), optName);
            if (optIndex >= 0)
                optSet[optSetIndex].deleteOption(optIndex);
        } else {
            System.out
                    .println("Option Set index out of bound, can not delete option");
        }
    }

    public void deleteOption(int optSetIndex, int optIndex) {
        if (optSetIndex >= 0 && optSetIndex <= optSet.length - 1) {
            OptionSet ops1 = optSet[optSetIndex];
            if (optIndex >= 0 && optIndex <= ops1.getOptLen() - 1) {
                optSet[optSetIndex].deleteOption(optIndex);
            } else {
                System.out
                        .println("Option index out of bound, can not delete option");
            }
        } else {
            System.out
                    .println("Option Set index out of bound, can not delete option set");
        }
    }

    /*
     * deleteOption -- given the name of an OptionSet and name of an Option, if
     * it can be found, delete it.
     */
    public void deleteOption(String optSetName, String optName) {
        int optIndex = findOptionInAuto(optSetName, optName);
        if (optIndex >= 0) {
            optSet[findOptionSet(optSetName)].deleteOption(optIndex);
        }
    }

    /*
     * printAuto -- append information for output.
     */
    public void printAuto() {
        StringBuffer str = new StringBuffer();
        str.append("Model Name: ");
        str.append(getName());
        str.append("\nBase Price: $");
        str.append(getBasePrice());
        str.append("\nAvailable Options: ");

        for (int i = 0; i < optSet.length - 1; i++) {
            if (optSet[i] != null) {
                str.append(optSet[i].getName());
                str.append(", ");
            } else {
                str.append("null");
                str.append("(This option set has already been deleted),");
            }
        }
        if (optSet[optSet.length - 1] != null) {
            str.append(optSet[optSet.length - 1].getName());
            str.append("\n\n");
        } else {
            str.append("null");
            str.append("(This option set has already been deleted)\n");
        }
        str.append("Detailed Option Information: ");
        str.append("\n");

        for (int i = 0; i < optSet.length; i++) {
            if (optSet[i] != null) {
                str.append(optSet[i].getName());
                str.append(":\n");
                str.append(optSet[i].printOptSet());
            } else {
                str.append("The " + i
                        + " option set has already been deleted\n\n");
            }
        }

        System.out.println(str);
    }

}
