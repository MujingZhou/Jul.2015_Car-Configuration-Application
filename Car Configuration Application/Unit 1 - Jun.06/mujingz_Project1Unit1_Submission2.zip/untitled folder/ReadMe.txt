Readme.txt -- This file gives a quick overview of the submission folder.

Name: Mujing Zhou
Andrew ID: mujingz
Date of Submission: May.31.2015

The folder is organized as the following:

----1. 18641_P1U1 (project extracted from 18641_P1U1.zip)

    --model package
        --Automotive class
	--OptionSet class (Option class is an inner class)

    --util package
	--Util class

    --driver package
	--Driver class

    --Ford Focus.txt (Input of the project)

----2. 18641_P1U1.pdf 
    This is the diagram of 18641_P1U1 project.

----3. output.txt
    This is the text file of output of 18641_P1U1 project.

----4. Readme.txt
    This is the current file.

