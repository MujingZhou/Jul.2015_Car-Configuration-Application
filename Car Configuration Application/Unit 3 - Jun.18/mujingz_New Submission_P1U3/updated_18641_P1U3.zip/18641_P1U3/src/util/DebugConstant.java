package util;

public interface DebugConstant {
    public boolean debug= true;
}
