package driver;

import util.DebugConstant;
import adapter.BuildAuto;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 17 2015
 * 
 * Driver class -- This class simulates the whole project. The simulation includes the new 
 * features such as BuildAuto and stuffs related with choices in Unit 2 as well as the old 
 * features of Unit 1.
 */

public class Driver{

    public static void main(String[] args) {
          
        BuildAuto f1=new BuildAuto();
        
        System.out.println("------------------Beginning to build the first car------------------");
        f1.buildAuto();
        System.out.println("------------------End to build the first car------------------");
        
        System.out.println("------------------Beginning to build the second car------------------");
        f1.buildAuto();
        
        
        System.out.println("Synchronized output for updaing option set name:");
        f1.updateOptionSetName("BMW", "Color", "Color1");
        f1.updateOptionSetName("BMW", "Color1", "Color2");
        f1.updateOptionSetName("BMW", "Color2", "Color3");
        f1.updateOptionSetName("BMW", "Color3", "Color4");
        f1.updateOptionSetName("BMW", "Color4", "Color5");
        
                
        System.out.println();
        System.out.println();
             
        System.out.println("Unsynchronized output for updaing option set name:");
        f1.updateOptionSetNameUnsynchronize("BMW", "Color5", "Color6");
        f1.updateOptionSetNameUnsynchronize("BMW", "Color6", "Color7");
        f1.updateOptionSetNameUnsynchronize("BMW", "Color8", "Color9");
        f1.updateOptionSetNameUnsynchronize("BMW", "Color10", "Color11");
        f1.updateOptionSetNameUnsynchronize("BMW", "Color11", "Color12");
        
        System.out.println();
        System.out.println();
        
        System.out.println("Synchronized output for updaing option name:");
        f1.updateOptionName("BMW", "Color5", "Fort Knox Gold Clearcoat Metallic", "Metallic1");
        f1.updateOptionName("BMW", "Color5", "Metallic1", "Metallic2");
        f1.updateOptionName("BMW", "Color5", "Metallic2", "Metallic3");
        f1.updateOptionName("BMW", "Color5", "Metallic3", "Metallic4");
        f1.updateOptionName("BMW", "Color5", "Metallic4", "Metallic5");
        
        System.out.println();
        System.out.println();
            
        System.out.println("Unsynchronized output for updaing option name:");
        f1.updateOptionNameUnsynchronized("BMW", "Color5", "Metallic5", "Metallic6");
        f1.updateOptionNameUnsynchronized("BMW", "Color5", "Metallic6", "Metallic7");
        f1.updateOptionNameUnsynchronized("BMW", "Color5", "Metallic7", "Metallic8");
        f1.updateOptionNameUnsynchronized("BMW", "Color5", "Metallic8", "Metallic9");
        f1.updateOptionNameUnsynchronized("BMW", "Color5", "Metallic9", "Metallic10");
        
        
        System.out.println();
        System.out.println();
        
        System.out.println("Synchronized output for updaing option price:");
        f1.updateOptionPrice("BMW", "Color5", "Metallic5", 100);
        f1.updateOptionPrice("BMW", "Color5", "Metallic5", 200);
        f1.updateOptionPrice("BMW", "Color5", "Metallic5", 300);
        f1.updateOptionPrice("BMW", "Color5", "Metallic5", 400);
        f1.updateOptionPrice("BMW", "Color5", "Metallic5", 500);
        
        System.out.println();
        System.out.println();
        
        System.out.println("Unsynchronized output for updaing option price:");
        f1.updateOptionPriceUnsynchronize("BMW", "Color5", "Metallic5", 100);
        f1.updateOptionPriceUnsynchronize("BMW", "Color5", "Metallic5", 200);
        f1.updateOptionPriceUnsynchronize("BMW", "Color5", "Metallic5", 300);
        f1.updateOptionPriceUnsynchronize("BMW", "Color5", "Metallic5", 400);
        f1.updateOptionPriceUnsynchronize("BMW", "Color5", "Metallic5", 500);
        
        
        System.out.println();
        System.out.println();
        
        f1.deleteOptionSet("BMW", "Power Moonroof");
        f1.deleteOptionSet("BMW", "Power Moonroof");
        
        System.out.println();
        System.out.println();
        
        f1.deleteOption("BMW", "Transmission", "automatic");
        f1.deleteOption("BMW", "Transmission", "automatic");
        
        System.out.println();
        System.out.println();
        
        
        f1.printAuto("BMW");
        System.out.println("------------------End to to build the second car------------------");
        
//        util1.serializeAuto(f1.getAuto("Ford Focus"), "A.dat");
//        Automobile newFordZTW = util1.deserializeAuto("A.dat");
//
//        newFordZTW.setBasePrice(10000);
//        newFordZTW.setName("Focus Wagon");
//
//        newFordZTW.getOptionSet(10);
//        
//        if (newFordZTW.findOptionSet("Transmission") >= 0) {
//            System.out.println("Given option set found");
//        }
//
//        if (newFordZTW.findOptionInAuto("Color",
//                "Fort Knox Gold Clearcoat Metallic") >= 0) {
//            System.out.println("Given option found");
//        }
//
//        newFordZTW.updateOptionSet("Po", "Moonroof Power new");
//        
//        newFordZTW.updateOption("Color", "Infra-Red Clearcoat", "Red");
//        newFordZTW.updateOption("Color", "Liquid Grey Clearcoat Metallic", 100);
//        newFordZTW.updateOption("Color", "Grabber Green Clearcoat Metallic",
//                "Green new", 200);
//
//        newFordZTW.printAuto();
//
//        newFordZTW.setOptionChoice("Transmission", "manual");
//        System.out.print("After choosing the Transmission, the total price is : ");
//        System.out.println(newFordZTW.getTotalPrice());
//
//        newFordZTW.setOptionChoice("Color", "Green new");
//        System.out.print("After choosing the Color, the total price is : ");
//        System.out.println(newFordZTW.getTotalPrice());

    }

}
