package adapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import util.Util;
import model.Automobile;
import model.Fleet;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 11 2015
 * 
 * ProxyAutomobile -- This class is an abstract class which is extended by the 
 * BuildAuto class. This class has a static field of a Fleet object and some 
 * methods from the CreateAuto and UpdateAuto interface to operate on the Automobile
 * elements in the fleet field.
 *  
 */

public abstract class ProxyAutomobile {
    private static Fleet fleet;
    
    /*
     * ProxyAutomobile -- default constructor of ProxyAutomobile class with no argument.
     */
    public ProxyAutomobile(){
        fleet=new Fleet();
    }
    
    /*
     * getFleet -- get the fleet field of the ProxyAutomobile class.
     */
    public Fleet getFleet(){
        return fleet;
    }
    
    /*
     * getAuto -- given the model name, search for the Automobile object 
     * and return it.
     */
    public Automobile getAuto(String modelName){
        return fleet.searchAuto(modelName);
    }
    
    /*
     * buildAuto -- build an Automobile object from the filename given from 
     * the user. buildAutoObject method in the util class will be called 
     * for the building.
     * In this method, the "Text file not found" exception is handled.
     */
    public void buildAuto() {
        Automobile a1=new Automobile();
        Util util1=new Util();
        try{
            System.out.println("Please enter the filename:");
            InputStreamReader isr = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(isr);
            String s = br.readLine();
            util1.buildAutoObject(s, a1);
            
            }
            catch (IOException e)
        {
                e.printStackTrace();
        }

        fleet.addAuto(a1.getName(), a1);
    }
    
    /*
     * printAuto -- given the model name, if the name can be found
     * print out the related information of the corresponding Automobile.
     */
    public void printAuto(String modelName)
    {
        Automobile a1=fleet.searchAuto(modelName);
        if (a1!=null)
        {
            a1.printAuto();
        }
        else {
            System.out.println("Model Name not found");
        }
    }
    
    /*
     * updateOptionSetName -- given the model name and the old name of the OptionSet,
     * if such model can be found, set the name of this OptionSet
     * to be the new name given by newName parameter.
     * If not found, just prompt a reminder message.
     */
    public void updateOptionSetName(String modelName, String optionSetName, String newName)
    {
        Automobile a1=fleet.searchAuto(modelName);
        if (a1!=null)
        {
            a1.updateOptionSet(optionSetName, newName);
        }
        else {
            System.out.println("Model Name not found, can not update the option set name");
        }
    }
    
    /*
     * updateOptionPrice -- given the name of the model name and the name of OptionSet
     * and name of the option, if such Option in such OptionSet can be found, 
     * set the price of this Option to be the new price given by newPrice parameter.
     * If not found, just prompt a reminder message.
     */
    public void updateOptionPrice(String modelName, String optionName, String option, float newPrice)
    {
        Automobile a1=fleet.searchAuto(modelName);
        if (a1!=null)
        {
            a1.updateOption(optionName,option,newPrice);
        }
        else {
            System.out.println("Model Name not found, can not update the option price");
        }
    }
    
    
}
