package adapter;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 11 2015
 * 
 * BuildAuto -- class that extends the ProxyAutomobile abstract class and implements
 * the two interfaces.
 */
public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto{
    
}
