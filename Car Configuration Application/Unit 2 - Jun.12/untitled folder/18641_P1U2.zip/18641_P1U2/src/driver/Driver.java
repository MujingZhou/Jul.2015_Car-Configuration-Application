package driver;

import adapter.BuildAuto;
import model.Automobile;
import util.Util;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 11 2015
 * 
 * Driver class -- This class simulates the whole project. The simulation includes the new 
 * features such as BuildAuto and stuffs related with choices in Unit 2 as well as the old 
 * features of Unit 1.
 */

public class Driver {

    public static void main(String[] args) {
        
        Util util1 = new Util();       
        BuildAuto f1=new BuildAuto();
        
        System.out.println("------------------Beginning to build the first car------------------");
        f1.buildAuto();
        f1.printAuto("Ford Focus");
        System.out.println("------------------End to build the first car------------------");
        
        System.out.println("------------------Beginning to build the second car------------------");
        f1.buildAuto();
        f1.printAuto("BMW");
        System.out.println("------------------End to to build the second car------------------");
        
        util1.serializeAuto(f1.getAuto("Ford Focus"), "A.dat");
        Automobile newFordZTW = util1.deserializeAuto("A.dat");

        newFordZTW.setBasePrice(10000);
        newFordZTW.setName("Focus Wagon");

        newFordZTW.getOptionSet(10);
        
        if (newFordZTW.findOptionSet("Transmission") >= 0) {
            System.out.println("Given option set found");
        }

        if (newFordZTW.findOptionInAuto("Color",
                "Fort Knox Gold Clearcoat Metallic") >= 0) {
            System.out.println("Given option found");
        }

        newFordZTW.updateOptionSet("Po", "Moonroof Power new");
        
        newFordZTW.updateOption("Color", "Infra-Red Clearcoat", "Red");
        newFordZTW.updateOption("Color", "Liquid Grey Clearcoat Metallic", 100);
        newFordZTW.updateOption("Color", "Grabber Green Clearcoat Metallic",
                "Green new", 200);

        newFordZTW.printAuto();

        newFordZTW.setOptionChoice("Transmission", "manual");
        System.out.print("After choosing the Transmission, the total price is : ");
        System.out.println(newFordZTW.getTotalPrice());

        newFordZTW.setOptionChoice("Color", "Green new");
        System.out.print("After choosing the Color, the total price is : ");
        System.out.println(newFordZTW.getTotalPrice());

    }

}
