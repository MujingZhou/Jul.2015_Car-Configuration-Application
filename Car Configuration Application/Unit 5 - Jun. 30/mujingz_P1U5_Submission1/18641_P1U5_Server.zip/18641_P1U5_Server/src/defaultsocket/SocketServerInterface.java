package defaultsocket;


/* Name: Mujing Zhou
* Andrew ID: mujingz
* Date: Jun. 24 2015
* 
* SocketServerInterface -- interfaces to for some methods defined in the DefaultSocketServer
* class.
*/
public interface SocketServerInterface {
    public boolean openConnection();
    public void handleSession();
    public void closeSession();

}
