package server;

import java.io.*;
import java.net.ServerSocket;
import java.util.Properties;

import adapter.BuildAuto;
import util.Util;
import model.Automobile;
import defaultsocket.DefaultSocketServer;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 24 2015
 * 
 * BuildCarModelOptions -- this class initialize a server socket and will set up the 
 * communication between the client and the server.
 */
public class BuildCarModelOptions implements AutoServer{
    private ServerSocket serverSocket;
    
    /*
     * BuildCarModelOptions -- default constructor of BuildCarModelOptions class with no
     * argument.
     */
    public BuildCarModelOptions(){}
    
    /*
     * BuildCarModelOptions -- default constructor of BuildCarModelOptions class with one
     * argument which initialize the port number field.
     */
    public BuildCarModelOptions(int port)
    {
        serverSocket=null;
        try{
            serverSocket =new ServerSocket(port);
        }
        catch (IOException e)
        {
            System.err.println("Server: Could not listen on port: "+port);
            System.exit(1);
        }
        
    }
    
    /*
     * begin -- this method starts the thread forever.
     */
    public void begin(){
        while(true){
        DefaultSocketServer clientSocket=acceptClient();
        System.out.println("Server: succeed to connect");
        clientSocket.start();
        }
    }
    
    /*
     * acceptClient -- this method will return the accepted client socket.
     */
    public DefaultSocketServer acceptClient()
    {       
        DefaultSocketServer clientSocket=new DefaultSocketServer(serverSocket);
        return clientSocket;
    }
    
    /*
     * acceptProperties -- this method will accepts the Properties object sent 
     * from the client.
     */
    public Properties acceptProperties(ObjectInputStream in){
        Properties props = new Properties();
        try {
            props = (Properties) in.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return props;
    }
    
    /*
     * addAuto -- use the Properties object to construct an Automobile object 
     * and add this object to the fleet.
     */
    public void addAuto(Properties props, BuildAuto bu1){
        Util util1 = new Util();
        Automobile a1 = util1.parseProperty(props);
        a1.printAuto();
        bu1.addAutomobile(a1);
    }

    public void addAutomobile(Automobile a1) {
        
    }

    public void listAvailableModel(BuildAuto bu1) {
        
    }

    public void sendObject() {
        
    }
    
}
