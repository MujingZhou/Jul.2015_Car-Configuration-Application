package defaultsocket;

/* Name: Mujing Zhou
* Andrew ID: mujingz
* Date: Jun. 24 2015
* 
* SocketServerConstants -- interfaces to store some constants that may be used by the 
* DefaultSocketServer class.
*/

public interface SocketServerConstants {
    public int iECHO_PORT = 7;
    public int iDAYTIME_PORT = 13;
    public int iSMTP_PORT = 25;
    public boolean DEBUG = true;
}
