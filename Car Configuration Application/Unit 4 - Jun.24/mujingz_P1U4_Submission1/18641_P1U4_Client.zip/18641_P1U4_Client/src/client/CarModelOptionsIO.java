package client;

import defaultsocket.DefaultSocketClient;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 24 2015
 * 
 * CarModelOptionsIO -- this class initialize a DefaultSocketClient in a given IP address
 * on a given port number and start the thread.
 */

public class CarModelOptionsIO {
    DefaultSocketClient clientSocketClient;
    
    /*
     * CarModelOptionsIO -- default constructor of CarModelOptionsIO class with no
     * argument.
     */
    public CarModelOptionsIO()   
    {
        clientSocketClient=new DefaultSocketClient("128.237.204.208",4300);       
    }
    
    /*
     * begin -- this method starts the thread.
     */
    public void begin(){
        clientSocketClient.start();
    }
}
