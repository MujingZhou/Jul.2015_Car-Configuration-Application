package database;

import java.sql.Statement;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jul.06 2015
 * 
 * CreateDataBase -- Interface for create database methods.
 *  
 */
public interface CreateDataBase {
    
    public void createDataBase(Statement myStatement);      
        
}
