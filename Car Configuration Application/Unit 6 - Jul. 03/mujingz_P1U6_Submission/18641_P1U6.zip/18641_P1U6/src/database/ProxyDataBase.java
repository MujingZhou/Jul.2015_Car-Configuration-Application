package database;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import model.Automobile;


/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jul.06 2015
 * 
 * ProxyDataBase -- This class is an abstract class which is extended by the 
 * BuildAutoInDataBase. This class has fields of the Connection and Statement of the
 * corresponding SQP database. Four kinds of methods are defined in this class: 1. 
 * CreateDataBase, 2. InSertAutoInDataBase, 3. UpdateAutoInDataBase, 4. DeleteAutoInDataBase.
 * Also, these four kinds of methods are the four interfaces that will be implemented by the
 * BuildAutoInDataBase class.
 * Also, methods in this class will be called by an object of BuildAutoInDataBase in the proxyAutomobile
 * class.
 *  
 */
public abstract class ProxyDataBase {
    private Connection myConnection;
    private Statement myStatement;

    public Connection getMyConnection() {
        return myConnection;
    }

    public Statement getMyStatement() {
        return myStatement;
    }

    /*
     * connectDataBase -- connect to the local mysql database.
     */
    public void connectDataBase() {
        String url = "jdbc:mysql://localhost";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            // PrintWriter out=new PrintWriter(System.out);
            // DriverManager.setLogWriter(out);
            myConnection = DriverManager.getConnection(url, "root", "");
            myStatement = myConnection.createStatement();
            myStatement.setQueryTimeout(180);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }

    }

    /*
     * createDataBase -- create the databse from the given text file..
     */
    public void createDataBase(Statement myStatement) {
        String filename = "create_database.txt";
        FileReader file;
        try {
            file = new FileReader(filename);

            BufferedReader buff = new BufferedReader(file);
            String line;
            while ((line = buff.readLine()) != null) {
                myStatement.executeUpdate(line);
            }
            buff.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
    }

    /*
     * insertAutoToDataBase -- This method is used to create three tables about an 
     * Automobile in the database. The first table is Automobile, the second is OptionSet
     * and the third is Options.
     */
    public void insertAutoToDataBase(Statement myStatement,
            Connection myConnection, Automobile a1) {
        String filename = "add_operations.txt";
        String[] keywordSet1 = { "Insert Automobile", "Select AutoID",
                "Insert OptionSet", "Select OptionSetID", "Insert Option" };

        HashMap<String, String> map1 = new HashMap<>();
        try {
            map1 = parseAddOperation(filename, keywordSet1);

            String modelName = a1.getName();
            String makeName = a1.getMake();
            float basePrice = a1.getBasePrice();
            String[] optSetName = a1.getOptionSetName();
            PreparedStatement ps1 = myConnection.prepareStatement("");

            addAutoDB(map1, keywordSet1[0], ps1, myConnection, modelName,
                    makeName, basePrice);
            int autoID = selectAutoIDDB(map1, keywordSet1[1], ps1,
                    myConnection, modelName);

            for (int i = 0; i < a1.getOptionSetLength(); i++) {
                addOptionSetDB(map1, keywordSet1[2], ps1, myConnection,
                        optSetName[i], autoID);
                String optName[] = a1.getOptionNameByIndex(i);
                int optionSetID = selectOptionSetIDDB(map1, keywordSet1[3],
                        ps1, myConnection, optSetName[i], autoID);

                float optPrice[] = a1.getOptionPriceByIndex(i);
                for (int j = 0; j < optName.length; j++) {
                    addOptionsDB(map1, keywordSet1[4], ps1, myConnection,
                            optName[j], optPrice[j], optionSetID);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * deleteAutoMobileInDataBase -- given the model name of an Automobile object,
     *  this method will delete the related automobile information from the Automobile table 
     *  in the database.
     */
    public void deleteAutoMobileInDataBase(Statement myStatement,
            Connection myConnection, String autoName){
        char rep;
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String filename = "delete_operations.txt";
        String[] keywordSet2 = { "Delete Automobile", "Delete OptionSet",
                "Delete Option" };
        PreparedStatement ps1;
        try {
            ps1 = myConnection.prepareStatement("");
       
        HashMap<String, String> map1 = parseDeleteOperation(filename,
                keywordSet2);
        System.out.println("Are you sure to delete Automobile: " + autoName
                + " from the databse?(y/n)");
      
        rep = (char) br.read();
        while (rep != 'y' && rep != 'n') {
            System.out.println("Please enter y or n for selection!");
            rep = (char) br.read();
        }
        if (rep == 'y') {
            deleteTableDB(map1, keywordSet2[0], ps1, myConnection, autoName);
        } else
            System.out.println("You do not choose to delete!"); 
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }       
    }
    
    /*
     * deleteOptionSetInDataBase -- given the model name of an Automobile object and 
     * the name of the option set that you wish to delete,
     * this method will delete the related option set information from the OptionSet table 
     * in the database.
     */
    public void deleteOptionSetInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName){
        char rep;
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String filename = "delete_operations.txt";
        String[] keywordSet2 = { "Delete Automobile", "Delete OptionSet",
                "Delete Option" };
        PreparedStatement ps1;
        try {
            ps1 = myConnection.prepareStatement("");
        
        HashMap<String, String> map1 = parseDeleteOperation(filename,
                keywordSet2);
        
        System.out.println("Are you sure to delete optionSet: " + optionSetName
                + " from the databse?(y/n)");
        
        rep = (char) br.read();
        while (rep != 'y' && rep != 'n') {
            System.out.println("Please enter y or n for selection!");
            rep = (char) br.read();
        }
        if (rep == 'y') {
            deleteTableDB(map1, keywordSet2[1], ps1, myConnection,
                    optionSetName);
        } else
            System.out.println("You do not choose to delete!");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    /*
     * deleteOptionsInDataBase -- given the model name of an Automobile object and 
     * the name of the option set as well as the option name you wish to delete,
     * this method will delete the related option information from the Option table 
     * in the database.
     */
    public void deleteOptionInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName,
            String optionName){
        
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String filename = "delete_operations.txt";
        String[] keywordSet2 = { "Delete Automobile", "Delete OptionSet",
                "Delete Option" };
        PreparedStatement ps1;
        try {
            ps1 = myConnection.prepareStatement("");
        
        HashMap<String, String> map1 = parseDeleteOperation(filename,
                keywordSet2);
        System.out.println("Are you sure to delete option: " + optionName
                + " from the databse?(y/n)");
        char rep = (char) br.read();
        while (rep != 'y' && rep != 'n') {
            System.out.println("Please enter y or n for selection!");
            rep = (char) br.read();
        }
        if (rep == 'y') {
            deleteTableDB(map1, keywordSet2[2], ps1, myConnection, optionName);
        } else
            System.out.println("You do not choose to delete!");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    /*
     * deleteAutoInDataBase -- This method can delete three tables in one method.
     */
    public void deleteAutoInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName,
            String optionName) throws SQLException, IOException {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String filename = "delete_operations.txt";
        String[] keywordSet2 = { "Delete Automobile", "Delete OptionSet",
                "Delete Option" };
        PreparedStatement ps1 = myConnection.prepareStatement("");
        HashMap<String, String> map1 = parseDeleteOperation(filename,
                keywordSet2);

        System.out.println("Are you sure to delete option: " + optionName
                + " from the databse?(y/n)");
        char rep = (char) br.read();
        while (rep != 'y' && rep != 'n') {
            System.out.println("Please enter y or n for selection!");
            rep = (char) br.read();
        }
        if (rep == 'y') {
            deleteTableDB(map1, keywordSet2[2], ps1, myConnection, optionName);
        } else
            System.out.println("You do not choose to delete!");

        System.out.println("Are you sure to delete optionSet: " + optionSetName
                + " from the databse?(y/n)");
        br.read();
        rep = (char) br.read();
        while (rep != 'y' && rep != 'n') {
            System.out.println("Please enter y or n for selection!");
            rep = (char) br.read();
        }
        if (rep == 'y') {
            deleteTableDB(map1, keywordSet2[1], ps1, myConnection,
                    optionSetName);
        } else
            System.out.println("You do not choose to delete!");

        System.out.println("Are you sure to delete Automobile: " + autoName
                + " from the databse?(y/n)");
        br.read();
        rep = (char) br.read();
        while (rep != 'y' && rep != 'n') {
            System.out.println("Please enter y or n for selection!");
            rep = (char) br.read();
        }
        if (rep == 'y') {
            deleteTableDB(map1, keywordSet2[0], ps1, myConnection, autoName);
        } else
            System.out.println("You do not choose to delete!");

    }

    
    /*
     * updateAutoInDataBase -- given the model name and the new base price, this 
     * method will update the Price in the Automobile table to this new value.
     */
    public void updateAutoInDataBase(Statement myStatement,
            Connection myConnection, String oldName, float newPrice)
            {
        String filename = "update_operations.txt";
        String[] keywordSet3 = { "Update Automobile", "Update OptionSet",
                "Update Option Price", "Update Option Name" };
        HashMap<String, String> map1;
        try {
            map1 = parseUpdateOperation(filename,
                    keywordSet3);
        
        PreparedStatement ps1 = myConnection.prepareStatement("");
        updateAutoNameDB(map1, keywordSet3[0], ps1, myConnection, oldName,
                newPrice);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /*
     * updateOptionSetInDataBase -- given the model name and the old option set
     * name as well as the new option set name you wish to update to, this methods will
     * update such optionset name in the OptionSet table in the database.
     */
    public void updateOptionSetInDataBase(Statement myStatement,
            Connection myConnection, String oldOptionSetName,
            String newOptionSetName, String autoName) {
        String filename1 = "update_operations.txt";
        String filename2 = "select_operations.txt";
        String[] keywordSet3 = { "Update Automobile", "Update OptionSet",
                "Update Option Price", "Update Option Name" };
        String[] keywordSet4 = { "Select AutoID", "Select OptionSetID" };
        HashMap<String, String> map1;
        try {
            map1 = parseUpdateOperation(filename1, keywordSet3);

            HashMap<String, String> map2 = parseSelectOperation(filename2,
                    keywordSet4);

            PreparedStatement ps1 = myConnection.prepareStatement("");
            int autoID = selectAutoIDDB(map2, keywordSet4[0], ps1,
                    myConnection, autoName);

            updateOptionSetNameDB(map1, keywordSet3[1], ps1, myConnection,
                    oldOptionSetName, newOptionSetName, autoID);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /*
     * updateOptionsInDataBase -- given the model name and the old option set
     * name, the option name as well as the new option price you wish to update to,
     *  this methods will update such option price in the Options table in the database.
     */
    public void updateOptionsInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName,
            String oldOptionName, float newOptionPrice) {
        String filename1 = "update_operations.txt";
        String filename2 = "select_operations.txt";
        String[] keywordSet3 = { "Update Automobile", "Update OptionSet",
                "Update Option Price", "Update Option Name" };
        String[] keywordSet4 = { "Select AutoID", "Select OptionSetID" };
        HashMap<String, String> map1;
        try {
            map1 = parseUpdateOperation(filename1,
                    keywordSet3);
        
        HashMap<String, String> map2 = parseSelectOperation(filename2,
                keywordSet4);

        PreparedStatement ps1 = myConnection.prepareStatement("");
        int autoID = selectAutoIDDB(map2, keywordSet4[0], ps1, myConnection,
                autoName);

        int optionSetID = selectOptionSetIDDB(map2, keywordSet4[1], ps1,
                myConnection, optionSetName, autoID);
        updateOptionPriceDB(map1, keywordSet3[2], ps1, myConnection,
                oldOptionName, newOptionPrice, optionSetID);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /*
     * updateOptionsInDataBase -- given the model name and the old option set
     * name, the option name as well as the new option name you wish to update to,
     *  this methods will update such option name in the Options table in the database.
     */
    public void updateOptionsInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName,
            String oldOptionName, String newOptionName) {
        String filename1 = "update_operations.txt";
        String filename2 = "select_operations.txt";
        String[] keywordSet3 = { "Update Automobile", "Update OptionSet",
                "Update Option Price", "Update Option Name" };
        String[] keywordSet4 = { "Select AutoID", "Select OptionSetID" };
        HashMap<String, String> map1;
        try {
            map1 = parseUpdateOperation(filename1,
                    keywordSet3);
        
        HashMap<String, String> map2 = parseSelectOperation(filename2,
                keywordSet4);

        PreparedStatement ps1 = myConnection.prepareStatement("");

        int autoID = selectAutoIDDB(map2, keywordSet4[0], ps1, myConnection,
                autoName);

        int optionSetID = selectOptionSetIDDB(map2, keywordSet4[1], ps1,
                myConnection, optionSetName, autoID);

        updateOptionNameDB(map1, keywordSet3[3], ps1, myConnection,
                oldOptionName, newOptionName, optionSetID);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /*
     * parseAddOperation -- this method will parse the file related with add operations
     * and store it using the keywordSet in the HashMap.
     */
    public HashMap<String, String> parseAddOperation(String filename,
            String[] keywordSet) throws IOException {
        HashMap<String, String> map1 = new HashMap<>();
        FileReader file = new FileReader(filename);
        BufferedReader buff = new BufferedReader(file);
        String line;
        while ((line = buff.readLine()) != null) {
            if (line.contains("insert") && line.contains("Automobile")) {
                map1.put(keywordSet[0], line);
            } else if (line.contains("insert") && line.contains("OptionSet")) {
                map1.put(keywordSet[2], line);
            } else if (line.contains("insert") && line.contains("Options")) {
                map1.put(keywordSet[4], line);
            } else if (line.contains("select") && line.contains("Automobile")) {
                map1.put(keywordSet[1], line);
            } else if (line.contains("select") && line.contains("OptionSet")) {
                map1.put(keywordSet[3], line);
            }
        }
        buff.close();
        return map1;
    }

    /*
     * parseDeleteOperation -- this method will parse the file related with delete operations
     * and store it using the keywordSet in the HashMap.
     */
    public HashMap<String, String> parseDeleteOperation(String filename,
            String[] keywordSet) throws IOException {
        HashMap<String, String> map1 = new HashMap<>();
        FileReader file = new FileReader(filename);
        BufferedReader buff = new BufferedReader(file);
        String line;
        while ((line = buff.readLine()) != null) {
            if (line.contains("delete") && line.contains("Automobile")) {
                map1.put(keywordSet[0], line);
            } else if (line.contains("delete") && line.contains("OptionSet")) {
                map1.put(keywordSet[1], line);
            } else if (line.contains("delete") && line.contains("Options")) {
                map1.put(keywordSet[2], line);
            }
        }
        buff.close();
        return map1;
    }

    /*
     * parseUpdateOperation -- this method will parse the file related with update operations
     * and store it using the keywordSet in the HashMap.
     */
    public HashMap<String, String> parseUpdateOperation(String filename,
            String[] keywordSet) throws IOException {

        HashMap<String, String> map1 = new HashMap<>();
        FileReader file = new FileReader(filename);
        BufferedReader buff = new BufferedReader(file);
        String line;
        while ((line = buff.readLine()) != null) {
            if (line.contains("update") && line.contains("Automobile")) {
                map1.put(keywordSet[0], line);
            } else if (line.contains("update") && line.contains("OptionSet")) {
                map1.put(keywordSet[1], line);
            } else if (line.contains("update") && line.contains("Options")
                    && line.contains("price")) {
                map1.put(keywordSet[2], line);
            } else if (line.contains("update") && line.contains("Options")
                    && line.contains("name")) {
                map1.put(keywordSet[3], line);
            }
        }
        buff.close();
        return map1;
    }

    /*
     * parseSelectOperation -- this method will parse the file related with select operations
     * and store it using the keywordSet in the HashMap.
     */
    public HashMap<String, String> parseSelectOperation(String filename,
            String[] keywordSet) throws IOException {

        HashMap<String, String> map1 = new HashMap<>();
        FileReader file = new FileReader(filename);
        BufferedReader buff = new BufferedReader(file);
        String line;
        while ((line = buff.readLine()) != null) {
            if (line.contains("select") && line.contains("Automobile")) {
                map1.put(keywordSet[0], line);
            } else if (line.contains("select") && line.contains("OptionSet")) {
                map1.put(keywordSet[1], line);
            }
        }
        buff.close();
        return map1;
    }

    /*
     * getQuestionMarkNum -- this method will return the number of the question marks 
     * in a string.
     */
    public int getQuestionMarkNum(String line) {
        int num = 0;
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '?') {
                num++;
            }
        }
        return num;
    }

    /*
     * setPreparedStatement -- this method will set the preparedStatement automatically
     * using the value array.
     */
    public PreparedStatement setPreparedStatement(int numQuestionMark,
            Object[] value, PreparedStatement ps) throws SQLException {
        for (int i = 0; i < numQuestionMark; i++) {
            if (value[i].getClass().equals(Float.class)) {
                ps.setFloat(i + 1, (float) value[i]);
            }

            else if (value[i].getClass().equals(String.class)) {
                ps.setString(i + 1, (String) value[i]);
            }

            else if (value[i].getClass().equals(Integer.class)) {
                ps.setInt(i + 1, (int) value[i]);
            }
        }
        return ps;
    }

    /*
     * addAutoDB -- this method will execute the add sql commands and add auto to the database.
     */
    public void addAutoDB(HashMap<String, String> map1, String keyword,
            PreparedStatement ps1, Connection myConnection, String modelName,
            String makeName, float basePrice) throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { modelName, makeName, basePrice };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ps1.executeUpdate();
    }

    /*
     * addOptionSetDB -- this method will execute the add sql commands and add OptionSet to the database.
     */
    public void addOptionSetDB(HashMap<String, String> map1, String keyword,
            PreparedStatement ps1, Connection myConnection,
            String optionSetName, int autoID) throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { optionSetName, autoID };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ps1.executeUpdate();
    }

    /*
     * addOptionsDB -- this method will execute the add sql commands and add Options to the database.
     */
    public void addOptionsDB(HashMap<String, String> map1, String keyword,
            PreparedStatement ps1, Connection myConnection, String optionName,
            float optionPrice, int optionSetID) throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { optionName, optionPrice, optionSetID };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ps1.executeUpdate();
    }

    /*
     * selectAutoDB -- this method will execute the select sql and get the autoid.
     */
    public int selectAutoIDDB(HashMap<String, String> map1, String keyword,
            PreparedStatement ps1, Connection myConnection, String optionName)
            throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { optionName };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ResultSet rs = ps1.executeQuery();
        int autoID = -1;
        while (rs.next()) {
            autoID = rs.getInt("id");
        }
        return autoID;
    }

    /*
     * selectOptionSetIDDB -- this method will execute the select sql and get the optionsetid.
     */
    public int selectOptionSetIDDB(HashMap<String, String> map1,
            String keyword, PreparedStatement ps1, Connection myConnection,
            String optionSetName, int autoID) throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { optionSetName, autoID };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ResultSet rs = ps1.executeQuery();
        int optionSetID = -1;
        while (rs.next()) {
            optionSetID = rs.getInt("id");
        }
        return optionSetID;
    }

    /*
     * deleteTableDB -- this method will execute the select sql and delete the 
     * corresponding table.
     */
    public void deleteTableDB(HashMap<String, String> map1, String keyword,
            PreparedStatement ps1, Connection myConnection, String deleteName)
            throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { deleteName };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ps1.executeUpdate();
    }


    /*
     * deleteTableDB -- this method will execute the select sql and delete the 
     * corresponding table.
     */
    public void updateAutoNameDB(HashMap<String, String> map1, String keyword,
            PreparedStatement ps1, Connection myConnection, String oldName,
            float newPrice) throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { newPrice, oldName };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ps1.executeUpdate();

    }


    /*
     * deleteTableDB -- this method will execute the select sql and delete the 
     * corresponding table.
     */
    public void updateOptionSetNameDB(HashMap<String, String> map1,
            String keyword, PreparedStatement ps1, Connection myConnection,
            String oldOptionSetName, String newOptionSetName, int autoID)
            throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { newOptionSetName, oldOptionSetName, autoID };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ps1.executeUpdate();

    }


    /*
     * deleteTableDB -- this method will execute the select sql and delete the 
     * corresponding price in the Option table.
     */
    public void updateOptionPriceDB(HashMap<String, String> map1,
            String keyword, PreparedStatement ps1, Connection myConnection,
            String oldOptionName, float newOptionPrice, int optionSetID)
            throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { newOptionPrice, oldOptionName, optionSetID };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ps1.executeUpdate();

    }


    /*
     * updateOptionNameDB -- this method will execute the update sql and update the name in 
     * corresponding Option Table.
     */
    public void updateOptionNameDB(HashMap<String, String> map1,
            String keyword, PreparedStatement ps1, Connection myConnection,
            String oldOptionName, String newOptionName, int optionSetID)
            throws SQLException {
        String subCommand = map1.get(keyword);
        ps1 = myConnection.prepareStatement(subCommand);
        int numQuestionMark = getQuestionMarkNum(subCommand);
        Object[] ob = { newOptionName, oldOptionName, optionSetID };
        ps1 = setPreparedStatement(numQuestionMark, ob, ps1);
        ps1.executeUpdate();
    }


    /*
     * displayTable -- this method will execute the select sql and display the table.
     */
    public void displayTable(Statement myStatement, String tableName)
            {
        String filename = "display_operations.txt";
        FileReader file;
        try {
            file = new FileReader(filename);
        
        BufferedReader buff = new BufferedReader(file);
        String line;
        while ((line = buff.readLine()) != null) {
            if (line.contains("select") && line.contains(tableName)) {
                ResultSet rs = myStatement.executeQuery(line);

                if (tableName.equals("Automobile")) {
                    String keywords[] = { "ID", "Name", "Make", "Price" };
                    printFormat(rs, keywords, tableName);
                } else if (tableName.equals("OptionSet")) {
                    String keywords[] = { "id", "name", "autoid" };
                    printFormat(rs, keywords, tableName);
                } else if (tableName.equals("Options")) {
                    String keywords[] = { "id", "name", "price", "optionsetid" };
                    printFormat(rs, keywords, tableName);
                }

            }
        }
        buff.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }


    /*
     * printFormat -- this method will print out the Table in a good 
     * format and easy for user to understand.
     */
    public void printFormat(ResultSet rs, String[] keywords, String tableName)
            throws SQLException {
        System.out.println("This is the table of " + tableName);
        for (int i = 0; i < keywords.length; i++) {
            if (i == 0) {
                System.out.printf(keywords[i]);
            } else {
                System.out.printf("%-35s", keywords[i]);
            }
            System.out.printf("\t\t");

        }
        System.out.println();
        while (rs.next()) {
            for (int i = 0; i < keywords.length; i++) {
                if (i == 0) {
                    System.out.format(rs.getString(keywords[i]).toString());
                } else
                    System.out.printf("%-35s", rs.getString(keywords[i])
                            .toString());

                System.out.format("\t\t");

            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }

}
