package database;

import java.sql.Connection;
import java.sql.Statement;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jul.06 2015
 * 
 * DeleteAutoInDataBase -- Interface for delete methods.
 *  
 */
public interface DeleteAutoInDataBase {
    public void deleteAutoMobileInDataBase(Statement myStatement,
            Connection myConnection, String autoName);
    public void deleteOptionSetInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName);
    public void deleteOptionInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName,
            String optionName);
}
