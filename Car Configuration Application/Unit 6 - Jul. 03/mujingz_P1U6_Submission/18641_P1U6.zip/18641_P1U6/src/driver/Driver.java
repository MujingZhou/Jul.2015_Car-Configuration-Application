package driver;

import adapter.BuildAuto;



/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 17 2015
 * 
 * Driver class -- This class simulates the whole project. The simulation includes the new 
 * features such as BuildAuto and stuffs related with choices in Unit 2 as well as the old 
 * features of Unit 1.
 */

public class Driver {

    public static void main(String[] args) throws Exception {
        
        
        BuildAuto f1=new BuildAuto();
        f1.startDataBase();
        
        
        
        System.out.println("------------------Beginning to build the first car------------------");
        f1.buildAuto();
        System.out.println("------------------End to build the first car------------------");
        
        System.out.println("------------------Beginning to build the second car------------------");
        f1.buildAuto();
        
        f1.updateBasePrice("Ford Focus", 19998);
        f1.updateOptionSetName("Z4", "Color", "Color1");
        f1.updateOptionPrice("Z4", "Transmission", "manual", -1000);
        f1.updateOptionName("Z4", "Transmission", "automatic", "totally-automatic");
        
        f1.displayTableInDataBase("Automobile");
        f1.displayTableInDataBase("OptionSet");
        f1.displayTableInDataBase("Options");
        
        f1.deleteOption("Z4", "Color1", "Fort Knox Gold Clearcoat Metallic");
        f1.displayTableInDataBase("Options");
        
        f1.deleteOptionSet("Z4", "Color1");
        f1.displayTableInDataBase("OptionSet");
        
        f1.deleteAuto("Z4");       
        f1.displayTableInDataBase("Automobile");
        
               
        f1.closeDataBase();
        
    }

}
