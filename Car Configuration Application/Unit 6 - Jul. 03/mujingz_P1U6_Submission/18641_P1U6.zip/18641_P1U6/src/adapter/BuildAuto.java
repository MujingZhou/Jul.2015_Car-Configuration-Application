package adapter;

import java.io.ObjectInputStream;
import java.util.Properties;

import scale.EditAuto;
import server.AutoServer;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jun. 17 2015
 * 
 * BuildAuto -- class that extends the ProxyAutomobile abstract class and implements
 * the three interfaces(CreateAuto, UpdateAuto and EditAuto)
 */
public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto, EditAuto, AutoServer{

    public void addAuto(Properties props, BuildAuto bu1) {
        
    }

    public Properties acceptProperties(ObjectInputStream in) {
        return null;
    }

    public void listAvailableModel(BuildAuto bu1) {
        
    }

    public void sendObject() {        
    }
    
}
