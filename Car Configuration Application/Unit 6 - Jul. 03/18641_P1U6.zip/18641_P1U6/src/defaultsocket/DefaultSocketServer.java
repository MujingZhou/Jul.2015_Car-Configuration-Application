package defaultsocket;

import java.io.*;
import java.net.*;

import adapter.BuildAuto;
import model.Automobile;
import server.BuildCarModelOptions;

/* Name: Mujing Zhou
* Andrew ID: mujingz
* Date: Jun. 24 2015
* 
* DefaultSocketServer -- this class is a revised version of the default socket class given by 
* the professor. This class deals with the main operations from the server.
*/
public class DefaultSocketServer extends Thread implements
        SocketServerInterface, SocketServerConstants {
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private Socket sock;
    private String strHost;
    private int iPort;

    /*
     * DefaultSocketServer -- default constructor of DefaultSocketServer class with one
     * arguments which initialize the serverSocket field. In this method, the connection
     * between client and server will be established via the accept() method.
     */
    public DefaultSocketServer(ServerSocket serverSocket) {

        try {
            this.sock = serverSocket.accept();
            InetAddress address = sock.getInetAddress();
            String hostIP = address.getHostAddress();
            setHost(hostIP);
            setPort(sock.getLocalPort());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /*
     * run -- this starts the thread and implements the following three methods.
     */
    public void run() {
        if (openConnection()) {
            handleSession();
            closeSession();
        }
    }

    /*
     * openConnection -- this method initializes those Object streams.
     */
    public boolean openConnection() {

        try {
            out = new ObjectOutputStream(sock.getOutputStream());
            out.flush();
            in = new ObjectInputStream(sock.getInputStream());
        } catch (Exception e) {
            if (DEBUG)
                System.err
                        .println("Unable to obtain stream to/from " + strHost);
            return false;
        }
        return true;
    }
    
    /*
     * handleUpload -- this method handles the case when the client chooses to upload a
     * file and how the server should interact with the client.
     */
    public void handleUpload(BuildAuto bu1) {
        boolean flag = true;
        while (flag)
            try {
                BuildCarModelOptions bc1=new BuildCarModelOptions();
                String fileFound = (String) in.readObject();
                if (fileFound.equals("Correct fileName")) {
                    flag=false;
                    String fileType = (String) in.readObject();
                    System.out
                            .println("Server: client choose to upload a file");
                    System.out.println("fileType: " + fileType);
                    if (fileType.equals("properties")) {
                        bc1.addAuto(bc1.acceptProperties(in), bu1);
                    }
                    if (fileType.equals("txt")) {
                        System.out.println("Server: client upload a txt file");
                        bu1.buildAuto();
                    }
                }
                
                
                
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
    }

    /*
     * listAvailableModel -- given an BuildAuto object, this method would print out
     * all the available model names on the serever side.
     */
    public void listAvailableModel(BuildAuto bu1){
        String[] modelName = bu1.getAutoModelName();
        try{
        out.writeObject(modelName);
        out.flush();

        String selectedModelName="";
        try {
            selectedModelName=(String)in.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("Server: client select " + selectedModelName);
        sendObject(bu1, selectedModelName);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
    /*
     * sendObject -- given an BuildAuto object and the selected model name, this 
     * method would write the Automobile object which corresponds with selected model
     * name.
     */
    public void sendObject(BuildAuto bu1, String selectedModelName){
        Automobile a1 = bu1.getAuto(selectedModelName);
        
        try{
        out.writeObject(a1);
        out.flush();
        }catch (IOException e) {
            e.printStackTrace();
        } 
    }
    
    /*
     * handleConfigure -- this methods handles the case that the client choose to
     * configure a car and how the server would interact with the client.
     */  
    public void handleConfigure(BuildAuto bu1) {        
            System.out.println("Server: client wish to configure a car");
            listAvailableModel(bu1);
    }

    /*
     * handQuit -- this methods handles the case that the client choose to
     * quit and how the server would interact with the client.
     */ 
    public void handleQuit() {
        System.out.println("Server: client chooses to quit");
        closeSession();
    }

    /*
     * handleSession -- based on the choice made from the user, different methods in the 
     * server side will be implemented.
     */ 
    public void handleSession() {

        BuildAuto bu1 = new BuildAuto();
        if (DEBUG)
            System.out
                    .println("Server: Handling session with " + strHost + ":" + iPort);
        while (true) {
                int choice = 0;
                try {
                    choice = (int) in.readObject();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                if (choice == 1) {
                    handleUpload(bu1);
                }

                if (choice == 2) {
                    handleConfigure(bu1);
                }

                if (choice == 3) {
                    handleQuit();
                    break;
                }           
        }

    }

    /*
     * closeSession -- this methods closes all the streams and the socket.
     */ 
    public void closeSession() {
        try {
            out = null;
            in = null;
            sock.close();
        } catch (IOException e) {
            if (DEBUG)
                System.err.println("Error closing socket to " + strHost);
        }
    }

    /*
     * setHost -- set the strHost field of this class.
     */
    public void setHost(String strHost) {
        this.strHost = strHost;
    }

    /*
     * setPort -- set the iPort field of this class.
     */
    public void setPort(int iPort) {
        this.iPort = iPort;
    }
    
    /*
     * getHost -- get the value of strHost field of this class.
     */
    public String getHost() {
        return strHost;
    }

    /*
     * getPort -- get the value of iPort field of this class.
     */
    public int getPort() {
        return iPort;
    }

}
