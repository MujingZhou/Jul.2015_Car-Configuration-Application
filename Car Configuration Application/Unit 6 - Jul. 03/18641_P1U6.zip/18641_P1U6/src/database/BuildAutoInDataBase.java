package database;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jul.06 2015
 * 
 * BuildAUtoINDataBase -- Abstract class that extends the ProxyDataBase and will implement four interfaces.
 *  
 */
public class BuildAutoInDataBase extends ProxyDataBase implements CreateDataBase, InsertAutoInDataBase, UpdateAutoInDataBase {

}
