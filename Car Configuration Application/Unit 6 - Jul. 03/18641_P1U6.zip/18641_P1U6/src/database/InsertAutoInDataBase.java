package database;

import java.sql.Connection;
import java.sql.Statement;

import model.Automobile;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jul.06 2015
 * 
 * InsertAutoInDataBase -- Interface for insert methods.
 *  
 */
public interface InsertAutoInDataBase {
    public void insertAutoToDataBase(Statement myStatement, Connection myConnection,Automobile a1);
}
