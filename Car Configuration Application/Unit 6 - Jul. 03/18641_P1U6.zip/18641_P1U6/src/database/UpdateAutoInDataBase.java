package database;

import java.sql.Connection;
import java.sql.Statement;

/* Name: Mujing Zhou
 * Andrew ID: mujingz
 * Date: Jul.06 2015
 * 
 * UpdateAutoInDataBase -- Interface for update methods.
 *  
 */
public interface UpdateAutoInDataBase {
    public void updateOptionsInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName,
            String oldOptionName, String newOptionName);
    
    public void updateOptionsInDataBase(Statement myStatement,
            Connection myConnection, String autoName, String optionSetName,
            String oldOptionName, float newOptionPrice);
    
    public void updateOptionSetInDataBase(Statement myStatement,
            Connection myConnection, String oldOptionSetName,
            String newOptionSetName, String autoName) ;
    
    public void updateAutoInDataBase(Statement myStatement,
            Connection myConnection, String oldName, float newPrice);
}
