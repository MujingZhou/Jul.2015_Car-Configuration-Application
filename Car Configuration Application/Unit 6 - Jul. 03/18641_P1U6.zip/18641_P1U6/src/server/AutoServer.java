package server;

import java.io.ObjectInputStream;
import java.util.Properties;

import model.Automobile;
import adapter.BuildAuto;

/* Name: Mujing Zhou
* Andrew ID: mujingz
* Date: Jun. 24 2015
* 
* AutoServer -- interfaces to for some methods defined in the BuildCarModelOptions and BuildAuto
* class.
*/

public interface AutoServer {
    public void addAuto(Properties props, BuildAuto bu1);
    public Properties acceptProperties(ObjectInputStream in);   
    public void addAutomobile(Automobile a1);    
    public void listAvailableModel(BuildAuto bu1);    
    public void sendObject();
}
